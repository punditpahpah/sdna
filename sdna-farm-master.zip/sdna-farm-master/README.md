# SuperDefi Farming 🥞

[![Actions Status](https://github.com/superdefi/sdna-farm/workflows/CI/badge.svg)](https://github.com/superdefi/sdna-farm/actions)
[![codecov](https://codecov.io/gh/pancakeswap/pancake-farm/branch/master/graph/badge.svg?token=5XMLP74IR0)](https://codecov.io/gh/pancakeswap/pancake-farm)

https://defi.superdna.io. Feel free to read the code. More details coming soon.

## Deployed Contracts / Hash

### BSCMAINNET

- CakeToken - https://bscscan.com/token/0x70e5FF10Df63539bc347734a9dAf8D447164A36e
- MasterChef - https://bscscan.com/address/0xE547cD868Bab254DDf3555f5889eF097a588923D
- (Uni|Cake)swapV2Factory - https://bscscan.com/address/0xBCfCcbde45cE874adCB698cC183deBcF17952812
- (Uni|Cake)swapV2Router02 - https://bscscan.com/address/0x05fF2B0DB69458A0750badebc4f9e13aDd608C7F
- (Uni|Cake)swapV2Pair init code hash - `0xd0d4c4cd0848c93cb4fd1f498d7013ee6bfb25783ea21593d5834f5d250ece66`
- MultiCall - 0xE1dDc30f691CA671518090931e3bFC1184BFa4Aa
